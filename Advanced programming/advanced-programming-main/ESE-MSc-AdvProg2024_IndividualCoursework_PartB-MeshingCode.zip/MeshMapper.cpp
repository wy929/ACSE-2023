#include "MeshMapper.h"

// Barycentric interpolation within a triangle
void MeshMapper::BarycentricInterpolation(
	const Node& p, const Node& p0, const Node& p1, const Node& p2,
	double& w0, double& w1, double& w2)
{
	double detT = (p1.y - p2.y) * (p0.x - p2.x) + (p2.x - p1.x) * (p0.y - p2.y);
	w0 = ((p1.y - p2.y) * (p.x - p2.x) + (p2.x - p1.x) * (p.y - p2.y)) / detT;
	w1 = ((p2.y - p0.y) * (p.x - p2.x) + (p0.x - p2.x) * (p.y - p2.y)) / detT;
	w2 = 1.0 - w0 - w1;
}

// Map values from one mesh to another using isogeometric linear triangles
void MeshMapper::MapMeshValues(const Mesh& sourceMesh, Mesh& targetMesh)
{
	// Map nodes and elements
	std::unordered_map<int, int> nodeMapping; // Map from source node index to target node index
	std::unordered_map<int, int> elementMapping; // Map from source element index to target element index

	// In a real implementation, you would perform the mapping based on your specific logic
	// Here, we assume a simple one-to-one mapping based on the order of nodes and elements
	for (int i = 0; i < sourceMesh.nodes.size(); ++i) {
		nodeMapping[i] = i < targetMesh.nodes.size() ? i : -1;
	}

	for (int i = 0; i < sourceMesh.elements.size(); ++i) {
		elementMapping[i] = i < targetMesh.elements.size() ? i : -1;
	}

	// Map values using interpolation
	targetMesh.temperatures.resize(targetMesh.nodes.size());
	targetMesh.pressures.resize(targetMesh.nodes.size());

	for (const auto& targetNode : targetMesh.nodes) {
		double totalWeight = 0.0;
		double interpolatedTemperature = 0.0;
		double interpolatedPressure = 0.0;

		for (const auto& sourceElement : sourceMesh.elements) {
			const Node& p0 = sourceMesh.nodes[sourceElement.nodeIndices[0]];
			const Node& p1 = sourceMesh.nodes[sourceElement.nodeIndices[1]];
			const Node& p2 = sourceMesh.nodes[sourceElement.nodeIndices[2]];

			double w0, w1, w2;
			BarycentricInterpolation(targetNode, p0, p1, p2, w0, w1, w2);

			int sourceIndex0 = sourceElement.nodeIndices[0];
			int sourceIndex1 = sourceElement.nodeIndices[1];
			int sourceIndex2 = sourceElement.nodeIndices[2];

			if (nodeMapping.count(sourceIndex0) && nodeMapping.count(sourceIndex1) &&
				nodeMapping.count(sourceIndex2)) {
				int targetIndex0 = nodeMapping[sourceIndex0];
				int targetIndex1 = nodeMapping[sourceIndex1];
				int targetIndex2 = nodeMapping[sourceIndex2];

				assert(targetIndex0 != -1 && targetIndex1 != -1 && targetIndex2 != -1);

				// Perform barycentric interpolation for temperatures and pressures
				interpolatedTemperature += w0 * sourceMesh.temperatures[sourceIndex0] +
					w1 * sourceMesh.temperatures[sourceIndex1] +
					w2 * sourceMesh.temperatures[sourceIndex2];

				interpolatedPressure += w0 * sourceMesh.pressures[sourceIndex0] +
					w1 * sourceMesh.pressures[sourceIndex1] +
					w2 * sourceMesh.pressures[sourceIndex2];

				totalWeight += 1.0;
			}
		}

		// Normalize the interpolated values
		if (totalWeight > 0.0) {
			targetMesh.temperatures.push_back(interpolatedTemperature / totalWeight);
			targetMesh.pressures.push_back(interpolatedPressure / totalWeight);
		}
	}
}
