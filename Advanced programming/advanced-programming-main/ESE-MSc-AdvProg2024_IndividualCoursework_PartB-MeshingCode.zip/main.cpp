#include <iostream>
#include <unordered_map>
#include <vector>
#include <cassert>

#include "Node.h"
#include "Element.h"
#include "Mesh.h"
#include "MeshMapper.h"

int main() 
{
    // Create a source mesh
    std::vector<Node> sourceNodes = { Node(0.0, 0.0, 0.0), Node(1.0, 0.0, 0.0), Node(1.0, 1.0, 0.0) };
    std::vector<Element> sourceElements = { Element({0, 1, 2}) };
    std::vector<double> sourceTemperatures = { 20.0, 25.0, 30.0 };
    std::vector<double> sourcePressures = { 100.0, 120.0, 90.0 };

    Mesh sourceMesh(sourceNodes, sourceElements, sourceTemperatures, sourcePressures);

    // Create a target mesh with different node and element locations
    std::vector<Node> targetNodes = { Node(0.5, 0.25, 0.0), Node(1.5, 0.5, 0.0), Node(1.0, 1.5, 0.0) };
    std::vector<Element> targetElements = { Element({0, 1, 2}) };
    std::vector<double> targetTemperatures, targetPressures;

    Mesh targetMesh(targetNodes, targetElements, targetTemperatures, targetPressures);

    // Display source mesh information
    std::cout << "Source Mesh:" << std::endl;
    sourceMesh.displayInfo();

    // Display target mesh information before mapping
    std::cout << "\nTarget Mesh Before Mapping:" << std::endl;
    targetMesh.displayInfo();

    // Map values from the source mesh to the target mesh using isogeometric linear triangles
    MeshMapper::MapMeshValues(sourceMesh, targetMesh);

    // Display target mesh information after mapping
    std::cout << "\nTarget Mesh After Mapping:" << std::endl;
    targetMesh.displayInfo();

    return 0;
}
