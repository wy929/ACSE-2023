#ifndef NODE_H
#define NODE_H

#include <vector>

// Class representing a node in the mesh
class Node {
public:
    double x, y, z;
    Node(double _x, double _y, double _z) : x(_x), y(_y), z(_z) {}
};

#endif